# SBX-031 confidential reproduction bundle

This attachment contains the deterministic controller, guest probe, bounded researcher-owned Cloudflare Worker, focused tests, two independent live evidence artifacts, and the draft HackerOne report for SBX-031.

The observed behavior is a candidate domain-allowlist bypass only if Vercel intends an `allow` domain entry to constrain the effective ECH inner destination. The draft report deliberately asks Vercel to confirm that policy semantic. Do not present the finding as an unconditional High without that clarification.

## Attachment contents

- `REPORT.md`: draft HackerOne report and severity caveat.
- `pocs/SBX-031/ech-domain-allowlist.ts`: bounded controller and assessment logic.
- `guest/ech-domain-probe.py`: one-request plain/ECH guest probe with parsed on-wire ClientHello attestation.
- `test/ech-domain-probe.test.ts`: focused local tests.
- `infra/h3-action-worker/`: owned non-reflecting HMAC endpoint, with platform observability disabled.
- `evidence/`: two confidential, body-free live artifacts. They retain hashes and opaque operation IDs, not the raw operator secret, HMAC key, or Vercel token.
- `ATTACHMENT-MANIFEST.sha256`: SHA-256 for every other file in this directory tree.

Keep this bundle and its evidence private to HackerOne and Vercel.

## Verify the attachment without making network requests

From the extracted `SBX-031-reproduction` directory:

```sh
shasum -a 256 -c ATTACHMENT-MANIFEST.sha256
npm ci
npx vitest run test/ech-domain-probe.test.ts
npx tsc --noEmit -p tsconfig.poc.json
python3 -m py_compile guest/ech-domain-probe.py
cd infra/h3-action-worker
npm ci
npm run check
```

`npm run check` performs a local Wrangler dry run and TypeScript check; it does not deploy the Worker. Dependency installation reaches the public npm registry, but none of these validation commands creates a Vercel sandbox or sends a probe request.

## Authorized live reproduction

Run this only with a HackerOne-eligible Vercel account you own and a Cloudflare account/Worker endpoint you own. The controller makes exactly four sequential endpoint requests, creates one non-persistent owned sandbox, rate-limits controller calls, and stops/deletes the sandbox in `finally` for every verdict.

### 1. Install the controller

Use Node.js 20.18 or newer:

```sh
npm ci
```

### 2. Deploy the temporary owned endpoint

Authenticate Wrangler, generate a fresh controller/Worker-only HMAC key without printing it, set the Worker secret from the protected file, and deploy:

```sh
cd infra/h3-action-worker
npm ci
npx wrangler login
npm run types
npm run check
umask 077
openssl rand -base64 48 | tr -d '\n' > ../../.sbx031-h3-action-key
npx wrangler secret put H3_ACTION_KEY < ../../.sbx031-h3-action-key
npx wrangler deploy
cd ../..
```

Record the resulting owned `https://<worker>.<account>.workers.dev` URL. If you change the Worker name in `wrangler.jsonc`, use that same name during cleanup.

### 3. Authenticate the owned Vercel account

Challenge researchers should sign in through the Sandbox CLI with their HackerOne-alias Vercel account:

```sh
npx sandbox login
```

Alternatively, export `VERCEL_TOKEN`, `VERCEL_TEAM_ID`, and `VERCEL_PROJECT_ID` together for one owned, eligible account. Never paste those values into this bundle or terminal transcripts.

### 4. Run the four-request proof matrix

Replace only the endpoint placeholder below. Read the same temporary HMAC key from the protected file; do not place it on a command line or in `.env`:

```sh
export H3_ACTION_KEY="$(tr -d '\r\n' < .sbx031-h3-action-key)"
export SBX031_SCOPE_CONFIRMATION='I_CONTROL_THE_ENDPOINT_AND_AUTHORIZE_BOUNDED_ECH_TESTING'
export SBX031_ENDPOINT_URL='https://<owned-worker>.<owned-account>.workers.dev/v1/h3-action'
npx tsx pocs/SBX-031/ech-domain-allowlist.ts
```

A reproduced `candidate` intentionally exits with status `1`; this is expected and prevents a bypass from being mistaken for a passing firewall test. Confirm all of the following in the compact terminal result:

- `verdict` is `candidate` and `candidate` is `true`;
- both `allow-*` controls pass;
- the exact policy update and independent same-session readback pass;
- `restrictedPlainBlocked` and `restrictedEchSucceeded` are both `true`;
- `restrictedEchBlocked` is `false`; and
- sandbox cleanup reports stopped/deleted with no errors.

The complete evidence is written mode `0600` to `artifacts/SBX-031-poc-<run-id>-private.json`. It stores no raw endpoint key, raw operator secret, Vercel token, raw ECHConfigList, response body, or raw ClientHello.

The program requires the submitting researcher to personally run and verify the PoC. Capture only the compact result or a carefully reviewed artifact; never capture credential entry or the temporary key.

### 5. Delete the temporary endpoint and local key

After reviewing the artifact:

```sh
cd infra/h3-action-worker
npx wrangler delete --name vsc-h3-action-swve
cd ../..
unset H3_ACTION_KEY SBX031_SCOPE_CONFIRMATION SBX031_ENDPOINT_URL
rm -f -- .sbx031-h3-action-key
```

If explicit Vercel credential variables were used, unset those separately. The controller already stops and deletes its sandbox, but verify your Vercel dashboard has no SBX-031 sandbox remaining before ending the test.

## Existing evidence integrity

The two included confidential artifacts have these source hashes:

```text
db730f9f7fb8bd4e1c46422f89c8ac9ee889a9753e0b683a9a7db40e35c7c4c8  evidence/SBX-031-poc-7fc8a05f-5fef-475f-986a-4e97e6d94067-private.json
9cff3e172c53aa0c4730bdad07b73118665bb90aaf0cda619ad12302977d4dce  evidence/SBX-031-poc-211e69f4-a86a-4bb8-8e72-b47b7692002a-private.json
```

See `REPORT.md` and `pocs/SBX-031/README.md` for the proof matrix, nonclaims, severity rationale, and primary technical references.
