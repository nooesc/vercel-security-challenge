# Controlled HMAC action Worker

This temporary Worker provides the researcher-owned action endpoint used by the SBX-017 HTTP/3 and SBX-031 ECH discriminators. It accepts only a bounded `GET /v1/h3-action` request and returns an opaque HMAC-derived operation ID. The correlation canary is not echoed or logged by the Worker. Platform observability is disabled in `wrangler.jsonc` so request query strings are not intentionally retained through Worker logs.

`H3_ACTION_KEY` is declared as a required secret and must be set with Wrangler; never commit it. The controller gets the same synthetic value but does not place it in guest configuration.

Validation and deployment:

```sh
npm ci
npm run types
npm run check
npx wrangler secret put H3_ACTION_KEY
npx wrangler deploy
```

Delete the temporary Worker after evidence capture:

```sh
npx wrangler delete --name vsc-h3-action-swve
```
