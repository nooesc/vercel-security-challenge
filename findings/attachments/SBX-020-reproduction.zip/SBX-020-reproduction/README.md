# SBX-020 reproduction bundle

This confidential bundle accompanies `REPORT.md`. The primary PoC is the same-session literal-`deny-all` differential. The explicit `169.254.0.0/16` controller and two earlier artifacts are included only as corroborating variants of the same MMDS firewall exemption.

The bundled controllers differ from the reporter's live-run copies only by allowing Vercel triage to set `SBX020_EXPECTED_ALIAS_EMAIL`, `SBX020_EXPECTED_TEAM_ID`, and `SBX020_EXPECTED_PROJECT_ID`. If those variables are omitted, the reporter's original HackerOne-alias values remain the defaults. The guest payloads, network policies, request sequence, sanitizers, and assessment logic are unchanged.

## Verify locally without Vercel calls

```sh
npm ci
npx vitest run test/sbx-020-deny-all-differential.test.ts test/mmds-link-local-probe.test.ts
npx tsc --noEmit
npx tsc --noEmit -p tsconfig.poc.json
```

## Run the primary differential

```sh
export VERCEL_TOKEN='<token for an owned Vercel test account>'
export VERCEL_TEAM_ID='<team_...>'
export VERCEL_PROJECT_ID='<prj_...>'
export SBX020_EXPECTED_ALIAS_EMAIL='<email on that Vercel account>'
export SBX020_EXPECTED_TEAM_ID="$VERCEL_TEAM_ID"
export SBX020_EXPECTED_PROJECT_ID="$VERCEL_PROJECT_ID"
npx tsx pocs/SBX-020/deny-all-mmds-differential.ts
```

This live command creates one fresh sandbox, uses the fixed researcher-owned public health endpoint as a control, and always attempts stop and delete. Do not execute it unless the account and program authorization are confirmed.

See `MANIFEST.sha256` for file hashes. The evidence files retain no response body, MMDS token value or digest, command output body, or sensitive response digest.
